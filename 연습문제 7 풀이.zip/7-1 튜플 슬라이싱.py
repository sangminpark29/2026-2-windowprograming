str = "WindowProgramming"

print(str[1:4]) # ind
print(str[9:]) # gramming
print(str[2:8:2]) # noP
print(str[-1:10:-1]) # gnimma

tup = tuple('WindowProgramming')
print(tup[1:4]) # ('i', 'n', 'd')
print(tup[9:]) # ('g', 'r', 'a', 'm', 'm', 'i', 'n', 'g')
print(tup[2:8:2]) # ('n', 'o', 'P')
print(tup[-1:10:-1]) # ('g', 'n', 'i', 'm', 'm', 'a')


