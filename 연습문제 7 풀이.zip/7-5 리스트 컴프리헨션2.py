text = "window programm"

res = [ch for ch in text if ch not in ['a', 'e', 'i', 'o', 'u']]
print(res)
