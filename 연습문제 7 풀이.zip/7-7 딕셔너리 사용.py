scores = {
    "Kim": [80, 90, 70],
    "Lee": [100, 85, 100],
    "Park": [95, 90, 85]
}

averages = {}
for name, lst in scores.items():
    averages[name] = sum(lst) / len(lst)

print("averages:", averages)

names = [name for name, avg in averages.items() if avg >= 90]
print("names:", names)
