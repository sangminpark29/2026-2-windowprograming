words = ["tiger", "lion", "elephant", "cat", "horse"]

res = [w for w in words if len(w) >= 5]
print(res)
