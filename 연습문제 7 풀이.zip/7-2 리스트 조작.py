num = []
num.extend([10, 20, 30])
num.insert(2, 40)

print("삭제된 요소:", num.pop())
print("요소들의 합:", sum(num))
