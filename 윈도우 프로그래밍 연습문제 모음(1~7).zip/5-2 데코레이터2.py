def deco2_add(type):
    def decorator(func):
        def wrapper(a, b):
            res = func(a, b)
            if type == "math":
                return f"{a} + {b} = {res}"
            elif type == "word":
                return f"The sum of {a} and {b} is {res}"
        return wrapper
    return decorator

@deco2_add(type="math")
def add(a, b):
    return a + b

print(add(1, 2))