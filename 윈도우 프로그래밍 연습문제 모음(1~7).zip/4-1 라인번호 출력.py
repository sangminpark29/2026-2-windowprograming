# 1. 라인번호를 붙여 출력하는 프로그램을 작성하시오
# 2. 라인번호를 붙여 ***.sav 형식의 이름으로 저장하는 프로그램을 작성하시오
while True:
        filename = input("읽을 파일명 입력 종료 버튼 = q").strip()

        if filename.lower() == 'q':
            print("프로그램 종료")
            break

        try:
            with open(filename, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            numbered_lines = []
            print(f"\n--- [{filename}] 내용 ---")

            for i, line in enumerate(lines, 1):
                formatted_line = f"{i} {line}"
                print(formatted_line, end="")
                numbered_lines.append(formatted_line)

            save_filename = filename + ".sav"

            with open(save_filename, 'w', encoding='utf-8') as f:
                f.writelines(numbered_lines)

            print(f"\n\n'{save_filename}' 파일 저장완료.")
            break

        except FileNotFoundError:
            print(f"'{filename}' 파일 찾기 실패 다시 입력\n")