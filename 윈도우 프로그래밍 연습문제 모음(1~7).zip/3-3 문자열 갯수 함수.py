def count_vowel(text):
    vowels = "aeiouAEIOU"
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    return count

if __name__ == "__main__":
    user_string = input("문자열 입력: ")
    vowel_count = count_vowel(user_string)
    print(f"문자열 속 모음의 개수: {vowel_count}")
