for n in range(1, 101):
    if n % 2 == 0:
        print(f"{n}은 짝수")
    else:
        print(f"{n}은 홀수")