import figure
import turtle
import math


class Triangle(figure.Polygon):
    count = 0

    def __init__(self):
        super().__init__(3)
        Triangle.count += 1
        self.serial = Triangle.count

    def getArea(self):
        return (math.sqrt(3) / 4) * (self.sideLen ** 2)

    def getSerial(self):
        return self.serial

    def draw(self):
        for step in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)
        input("Press any key to stop")

t = Triangle()
t.setSideLen(300)
print(f"Area: {t.getArea()}")
print(f"Serial: {t.getSerial()}")
t.draw()
