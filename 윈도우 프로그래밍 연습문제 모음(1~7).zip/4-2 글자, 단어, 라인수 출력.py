# 사용자가 요청한 파일을 읽어서 공백을 제외한 글자수, 단어의수, 그리고 라인의 수를 출력하는 출력하는 프로그램을 작성하시오

while True:
    filename = input("읽을 파일명 입력 종료 버튼 = q").strip()

    if filename.lower() == 'q':
        print("프로그램 종료")
        break

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()

        lines = content.splitlines()
        line_count = len(lines)

        words = content.split()
        word_count = len(words)

        char_count = sum(len(word) for word in words)

        print("\n" + "-" * 20)
        print(f"characters   : {char_count}")
        print(f"words        : {word_count}")
        print(f"lines        : {line_count}")
        print("-" * 20)
        break

    except FileNotFoundError:
        print(f"'{filename}' 파일 찾기실패 다시 입력\n")