import random

words = ["hangman", "python", "program", "tomato", "apple", "banana", "grape", "orange", "kiwi", "peach"]

while True:
    target_word = random.choice(words)
    guessed_letters = set()
    trials_left = 6

    print("\n게임 시작")

    while trials_left > 0:
        current_display = [ch if ch in guessed_letters else '_' for ch in target_word]
        print("현재 단어:", " ".join(current_display))

        if '_' not in current_display:
            print("Good Job!")
            break

        guess = input("하나의 알파벳만 입력하세요: ").strip().lower()

        if len(guess) != 1 or not guess.isalpha():
            print("하나의 알파벳만 입력하세요.")
            continue

        if guess in guessed_letters:
            print("이미 입력한 글자입니다.")
            continue

        if guess in target_word:
            guessed_letters.add(guess)
        else:
            trials_left -= 1
            print(f"Nope! {trials_left} trials left")

    if trials_left == 0:
        print(f"Fail!")

    play_again = input("\n다시할까요? (y/n): ").strip().lower()
    if play_again != 'y':
        print("게임종료")
        break