import math
a, b, c = 3, 4, 5
val1 = 1 / (1 + a / b + c)
print("1번 결과:", val1)

a, b, c = 1, 1, -6
root1 = (-b + math.sqrt(b**2 - 4*a*c)) / (2*a)
root2 = (-b - math.sqrt(b**2 - 4*a*c)) / (2*a)
print(f"2번 근: {root1}, {root2}")

r = 5
area = math.pi * r**2
print("3번 면적:", area)

beta, g = 2.0, 3.2
val2 = beta * math.exp(-g)
print("4번 결과:", val2)

x, mu, rho = 0, 1.5, 2.0
val3 = (1 / math.sqrt(2 * math.pi * rho**2)) * math.exp(-((x - mu)**2) / (2 * rho**2))
print("5번 결과:", val3)