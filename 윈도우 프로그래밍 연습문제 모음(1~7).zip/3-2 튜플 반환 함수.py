def min_max(numbers):
    small = min(numbers)
    big = max(numbers)

    return small, big

user_input = input("숫자를 공백으로 구분하여 입력: ")

string_list = user_input.split()

numbers = []
for item in string_list:
    numbers.append(int(item))

result = min_max(numbers)

print("최소값과 최대값:", result)
print("최소값:", result[0])
print("최소값:", result[1])
