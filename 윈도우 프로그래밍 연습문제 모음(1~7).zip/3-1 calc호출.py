def calc(*args, op='+'):
    if not args:
        return 0

    if op == '*':
        result = 1
        for num in args:
            result *= num
        return result
    else:
        result = 0
        for num in args:
            result += num
        return result

if __name__ == "__main__":
    res1 = calc(1, 1, 4, op='+')
    print(f"calc(1, 1, 4, op='+') -> 반환값: {res1}")

    res2 = calc(1, 2, op='*')
    print(f"calc(1, 2, op='*') -> 반환값: {res2}")

