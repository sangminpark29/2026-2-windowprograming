def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def do_operation(func, a, b):
    return func(a, b)

print(do_operation(add, 2, 3))
print(do_operation(sub, 5, 2))

print(do_operation(lambda a, b: a + b, 2, 3))
print(do_operation(lambda a, b: a - b, 5, 2))
