students = {}

print("학생 명단 작성 (종료: 학번 0 또는 이름 None)")
while True:
    student_id = input("학번 입력: ").strip()
    name = input("이름 입력: ").strip()

    if student_id == '0' or name == 'None':
        break

    students[student_id] = name

print("\n[생성된 학생 딕셔너리]")
print(students)

print("\n학번 조회")
while True:
    query = input("조회할 학번 : ").strip()

    if query == 'quit':
        print("프로그램 종료")
        break

    if query in students:
        print(f"이름: {students[query]}")
    else:
        print("not found!")